public class Terminal extends SyntaxItem {


}
