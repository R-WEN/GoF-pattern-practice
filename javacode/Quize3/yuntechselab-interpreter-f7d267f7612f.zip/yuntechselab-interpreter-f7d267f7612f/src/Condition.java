
public class Condition extends Nonterminal{
	public Condition(SyntaxItem left , SyntaxItem right) {
		super(left, right);
	}
}
