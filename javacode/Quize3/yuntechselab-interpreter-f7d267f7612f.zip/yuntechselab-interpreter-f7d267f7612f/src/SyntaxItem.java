
public abstract class SyntaxItem {
	public boolean eval(Context c){return false;}
	public  int val(Context c){return 0;}
}
