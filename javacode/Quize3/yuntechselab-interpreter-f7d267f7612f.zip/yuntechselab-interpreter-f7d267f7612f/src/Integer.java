
public class Integer extends Terminal{
	private int value;

	public Integer(int value) {
		this.value = value;
	}

	public int val(Context c) {
		// TODO Auto-generated method stub
		return value;
	}
}
